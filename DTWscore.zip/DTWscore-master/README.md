# DTWscore
Transcriptional heterogeneity analysis for time-series single-cell RNA-seq data
# How to use
step 1: download the file "DTWscore_1.0.tar" 

step 2: open your Rstudio

source("http://bioconductor.org/biocLite.R")

install.packages("~DTWscore_1.0.tar.gz",repos=NULL,type="source")

library(DTWscore)

# Now you can use "DTWscore" package, the detailed operation instruction is in the "DTWscore_pac.pdf" profile.
